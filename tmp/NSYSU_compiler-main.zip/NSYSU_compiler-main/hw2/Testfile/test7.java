class id {
	static int a;
	void main() {
		for (int i = 0; i < 0; i++)
			a++;
	}
}
