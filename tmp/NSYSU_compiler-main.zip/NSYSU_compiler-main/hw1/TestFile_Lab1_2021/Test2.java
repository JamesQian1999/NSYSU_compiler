// this is a comment // line */ /* with /* delimiters */ before the end

public class Test2 {
    int i = -100;
    double d = 12.25e+6;

    public static void main() {
/* this is a comment // line with some /* and
// delimiters */
    }
}
