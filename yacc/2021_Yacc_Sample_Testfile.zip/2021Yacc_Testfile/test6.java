class test6{
    void sum(){
//------NEVER USED
        int sumxyz = x + y + z ;
    }
    void main() {
//------ARRAY
        int [] i= new int [1];
        for(i[0] = 0; i[0]<5; i[0]++)
            i[0]++;

//------NEW CLASS
        Point lowerLeft = new Point() ;

//------ERROR CONDITION
        while(**/a++){
            print("error!!");
        }
//------CLASS DECLARE
        class Point {
            int x, y, z;
        }
    }

}
